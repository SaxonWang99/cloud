#---
# Excerpted from "Rails, Angular, Postgres, and Bootstrap",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material,
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose.
# Visit http://www.pragmaticprogrammer.com/titles/dcbang for more book information.
#---
require 'rails_helper'

feature "customer details" do
  include SignUpAndLogin
  given(:customer) { 
    create(:customer).tap { |customer|
      state = State.find_or_create_by!(code: "XX", name: "XX")
      CustomersBillingAddress.create!(
        customer: customer,
        address: Address.create!(street: Faker::Address.street_address,
                                 city: Faker::Address.city,
                                 state: state,
                                 zipcode: Faker::Address.zip))
      3.times do |i|
        CustomersShippingAddress.create!(
          primary: i == 0,
          customer: customer,
          address: Address.create!(street: Faker::Address.street_address,
                                   city: Faker::Address.city,
                                   state: state,
                                   zipcode: Faker::Address.zip)
        )
      end
      ActiveRecord::Base.connection.execute("REFRESH MATERIALIZED VIEW customer_details")
    }
  }

  scenario "see the basic details" do
    sign_up_and_log_in
    click_link "Customer Search"
    expect(page).to have_content("Customer Search")
    within "section.search-form" do
      expect(page).to have_selector("input[name='keywords']")
      fill_in "keywords", with: customer.first_name
    end
    expect(page).to have_selector("aside.loading-progress .not-loading")
    within "section.search-results" do
      click_button "View Details…"
    end
    within "article.panel-primary" do
      screenshot! filename: "customer-details.png"
    end
    screenshot! filename: "credit-card-info-stuck.png", selector: ".billing-info"
  end

  scenario "billing address is hidden if same as shipping" do
    customer.customers_billing_address.update_attribute(:address_id,customer.primary_shipping_address.id)
    ActiveRecord::Base.connection.execute("REFRESH MATERIALIZED VIEW customer_details")
    sign_up_and_log_in
    click_link "Customer Search"
    expect(page).to have_content("Customer Search")
    within "section.search-form" do
      expect(page).to have_selector("input[name='keywords']")
      fill_in "keywords", with: customer.first_name
    end
    expect(page).to have_selector("aside.loading-progress .not-loading")
    within "section.search-results" do
      click_button "View Details…"
    end
    within "article.panel-primary" do
      screenshot! filename: "customer-details-billing-same.png"
    end
    expect(find('input[type=checkbox]')).to be_checked
  end
end
