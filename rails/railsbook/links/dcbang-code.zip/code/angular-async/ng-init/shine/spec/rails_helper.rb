#---
# Excerpted from "Rails, Angular, Postgres, and Bootstrap",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material,
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose.
# Visit http://www.pragmaticprogrammer.com/titles/dcbang for more book information.
#---
ENV['RAILS_ENV'] ||= 'test'
require 'spec_helper'
require File.expand_path('../../config/environment', __FILE__)
require 'rspec/rails'
require 'support/easy_screenshots'
require 'support/sign_up_and_login'
require 'capybara/poltergeist'

Capybara.javascript_driver = :poltergeist
Capybara.default_driver    = :poltergeist

ActiveRecord::Migration.maintain_test_schema!
RSpec.configure do |config|
  config.fixture_path = "#{::Rails.root}/spec/fixtures"

  config.use_transactional_fixtures = false
  config.infer_spec_type_from_file_location!

  # rest of the file...

  config.add_setting :screenshots_dir
  config.screenshots_dir = "#{::Rails.root}/spec/screenshots"
  config.include(EasyScreenshots, type: :feature)
  config.include(FactoryGirl::Syntax::Methods)
  config.include(Devise::TestHelpers, type: :controller)

  config.before(:suite) do
    DatabaseCleaner.clean_with(:truncation)
    #ActiveRecord::Base.connection.execute %{SET session_replication_role = replica}
  end
  config.after(:suite) do
    #ActiveRecord::Base.connection.execute %{SET session_replication_role = DEFAULT}
  end

  config.before(:each) do
    DatabaseCleaner.strategy = :transaction
  end

  config.before(:each, :type => :feature) do
    DatabaseCleaner.strategy = :truncation
  end

  config.before(:each) do
    DatabaseCleaner.start
  end

  config.after(:each) do
    DatabaseCleaner.clean
  end
end
